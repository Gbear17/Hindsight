# Hindsight: A Personal Memory Archive
# Copyright (C) 2025 gcwyrick
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

# /home/gcwyrick/hindsight/app/hindsight_search.py (Refactored)
import subprocess
import os
import json
import numpy as np
import faiss
import google.generativeai as genai

# --- Imports from new modules ---
import config
from utils import setup_logger

# --- Setup logger ---
logger = setup_logger("HindsightSearch")

# --- Gemini API Configuration ---
try:
    genai.configure()
except Exception as e:
    logger.critical(f"Gemini API configuration failed in search module. Ensure GOOGLE_API_KEY is set. Error: {e}")

# --- Global State for Memoization ---
faiss_index = None
id_to_filepath_map = []

def init_search_components():
    """Initializes the FAISS index and the file path mapping once on startup."""
    global faiss_index, id_to_filepath_map
    if faiss_index is None and os.path.exists(config.FAISS_INDEX_PATH):
        try:
            logger.info("Loading FAISS index and file map into memory...")
            faiss_index = faiss.read_index(config.FAISS_INDEX_PATH)
            with open(config.ID_MAP_PATH, 'r', encoding='utf-8') as f:
                id_to_filepath_map = json.load(f)
            logger.info(f"FAISS index and file map loaded successfully ({faiss_index.ntotal} items).")
        except Exception:
            logger.exception("Failed to load FAISS index or file map. Semantic search will be unavailable.")

def get_recoll_matches(query):
    """Queries Recoll for exact keyword matches."""
    try:
        recoll_command = ["recoll", "-d", "-t", "-q", query]
        search_results_raw = subprocess.check_output(recoll_command).decode().strip()
        results = [{"source": "recoll", "content": res} for res in (search_results_raw.split('\n') if search_results_raw else [])]
        logger.debug(f"Recoll query returned {len(results)} matches.")
        return results
    except subprocess.CalledProcessError:
        logger.error("Recoll query failed. Is Recoll installed and the index configured?")
        return []

def get_faiss_matches(query, num_results=5):
    """Queries FAISS for semantic matches using the Gemini API."""
    if faiss_index is None or not id_to_filepath_map:
        logger.warning("FAISS index not loaded, skipping semantic search.")
        return []
    try:
        query_embedding = genai.embed_content(
            model=config.EMBEDDING_MODEL,
            content=query,
            task_type="retrieval_query"
        )['embedding']

        query_vector = np.array([query_embedding]).astype('float32')
        distances, indices = faiss_index.search(query_vector, num_results)

        results = []
        for i in range(len(indices[0])):
            idx = indices[0][i]
            if idx == -1: continue

            file_path = id_to_filepath_map[idx]
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            results.append({"source": "faiss (gemini)", "content": content, "distance": float(distances[0][i])})
        logger.debug(f"FAISS query returned {len(results)} matches.")
        return results
    except Exception:
        logger.exception("FAISS/Gemini semantic search failed.")
        return []

def refine_query_with_gemini(query):
    """Refines the user's query using the Gemini API."""
    try:
        logger.debug(f"Refining query with Gemini: '{query}'")
        model = genai.GenerativeModel(config.REFINER_MODEL)
        prompt = f"Analyze the following user search query to understand the user's intent. Refine the query by adding relevant synonyms, related concepts, or context-aware keywords that would improve a search across text documents. Do not hallucinate information. Respond with only the refined search query string.\nOriginal Query: \"{query}\"\nRefined Query:"
        response = model.generate_content(prompt)
        refined_query = response.text.strip()
        logger.debug(f"Refined query: '{refined_query}'")
        return refined_query
    except Exception:
        logger.exception("Gemini query refinement failed. Falling back to original query.")
        return query

def hybrid_search(query):
    """Combines Recoll and FAISS results after refining the query with Gemini."""
    logger.info(f"Performing hybrid search for query: '{query}'")
    refined_query = refine_query_with_gemini(query)
    recoll_results = get_recoll_matches(refined_query)
    faiss_results = get_faiss_matches(query)
    
    combined_results = recoll_results + faiss_results
    logger.info(f"Hybrid search complete. Found {len(combined_results)} total results.")
    return combined_results

# --- Initialize search components on module load ---
init_search_components()
