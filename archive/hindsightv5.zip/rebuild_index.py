# Hindsight: A Personal Memory Archive
# Copyright (C) 2025 gcwyrick
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

# /home/gcwyrick/hindsight/app/rebuild_index.py (Refactored)
import os
import glob
import json
import numpy as np
import faiss
import google.generativeai as genai
import time

# --- Imports from new modules ---
import config
from utils import setup_logger

# --- Setup logger using the new utility function ---
logger = setup_logger("HindsightRebuildIndex")
# Uncomment the line below to re-enable debug logging for this script
# logger.setLevel('DEBUG') 

# --- Gemini API Configuration ---
try:
    genai.configure()
except Exception as e:
    logger.critical(f"Gemini API configuration failed. Ensure GOOGLE_API_KEY is set. Error: {e}")
    exit(1)


def incremental_rebuild_faiss():
    """Performs a fast, incremental update of the FAISS index."""
    logger.info("Starting FAISS index update cycle.")
    os.makedirs(config.INDEX_DIR, exist_ok=True)

    # --- Load existing index and map ---
    if os.path.exists(config.FAISS_INDEX_PATH):
        try:
            index = faiss.read_index(config.FAISS_INDEX_PATH)
            with open(config.ID_MAP_PATH, 'r', encoding='utf-8') as f:
                id_to_filepath_map = json.load(f)
            logger.info(f"Loaded existing FAISS index with {index.ntotal} items.")
        except Exception:
            logger.exception("Failed to load existing FAISS index or map. Aborting cycle.")
            return
    else:
        index = faiss.IndexFlatIP(config.EMBEDDING_SIZE)
        id_to_filepath_map = []
        logger.info("No existing index found. Creating a new one.")

    # --- Find new files to process ---
    all_files = set(glob.glob(os.path.join(config.OCR_TEXT_DIR, "*.txt")))
    processed_files = set(id_to_filepath_map)
    new_files_to_process = sorted(list(all_files - processed_files))

    if not new_files_to_process:
        logger.info("No new files to index. Index is up to date.")
        return

    logger.info(f"Found {len(new_files_to_process)} new file(s) to index.")

    # --- Process new files and add to index ---
    new_embeddings = []
    new_filepaths = []
    for i, file_path in enumerate(new_files_to_process):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
                if not text.strip():
                    logger.debug(f"Skipping empty file: {os.path.basename(file_path)}")
                    continue

            embedding = genai.embed_content(
                model=config.EMBEDDING_MODEL,
                content=text,
                task_type="retrieval_document"
            )['embedding']

            new_embeddings.append(embedding)
            new_filepaths.append(file_path)
            logger.debug(f"Processed {i+1}/{len(new_files_to_process)}: {os.path.basename(file_path)}")

        except Exception:
            logger.exception(f"Failed to process and embed {file_path}. Skipping file.")
        
        time.sleep(1)

    # --- Save updated index and map ---
    if new_embeddings:
        try:
            embeddings_array = np.array(new_embeddings).astype('float32')
            index.add(embeddings_array)
            id_to_filepath_map.extend(new_filepaths)

            faiss.write_index(index, config.FAISS_INDEX_PATH)
            with open(config.ID_MAP_PATH, 'w', encoding='utf-8') as f:
                json.dump(id_to_filepath_map, f)
            logger.info(f"Successfully added {len(new_embeddings)} new items. Index now contains {index.ntotal} total items.")
        except Exception:
            logger.exception("A critical error occurred while saving the updated FAISS index or map file. Changes may be lost.")

if __name__ == "__main__":
    try:
        incremental_rebuild_faiss()
    except Exception:
        logger.critical("The index rebuild script encountered a fatal unhandled error.", exc_info=True)
        exit(1)
