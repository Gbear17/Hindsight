#!/bin/bash

# This script ensures the systemd services are running and REPORTS on the daemon's status.
# The daemon itself must be started by the user logging in (via autostart).

# --- 1. Check/Start the API Service ---
if systemctl --user is-active --quiet hindsight-api.service; then
  API_STATUS="✅ API: Running"
else
  systemctl --user enable --now hindsight-api.service
  API_STATUS="⚠️ API: Started"
fi

# --- 2. Check/Start the Indexing Timer ---
if systemctl --user is-active --quiet hindsight-rebuild.timer; then
  TIMER_STATUS="✅ Timer: Active"
else
  systemctl --user enable --now hindsight-rebuild.timer
  TIMER_STATUS="⚠️ Timer: Started"
fi

# --- 3. Check the Memory Daemon Status ---
if pgrep -f memory_daemon.py > /dev/null; then
  DAEMON_STATUS="✅ Daemon: Running"
else
  DAEMON_STATUS="❌ Daemon: STOPPED. Please log out and back in to start it."
fi

# --- Build the final message and send the notification ---
MESSAGE_BODY=$(printf "%s\n%s\n%s" "$API_STATUS" "$TIMER_STATUS" "$DAEMON_STATUS")

notify-send "Hindsight Status" "$MESSAGE_BODY" -i utilities-terminal
