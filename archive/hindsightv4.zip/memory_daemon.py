# Hindsight Polling Daemon (Final Production Version)
import time
import subprocess
import threading
import os
from PIL import Image

# --- Configuration ---
BASE_PATH = "/home/gcwyrick/hindsight"
POLL_INTERVAL = 5
SCREENSHOT_DIR = os.path.join(BASE_PATH, "data", "screenshots")
OCR_TEXT_DIR = os.path.join(BASE_PATH, "data", "ocr_text")
EXCLUDED_APPS = ["keepassxc", "vlc", "gnome-disks"]

# --- State Management ---
processing_lock = threading.Lock()
last_screenshot_paths = {}

def get_active_window_info():
    try:
        # Create a copy of the current environment and set DISPLAY explicitly
        env = os.environ.copy()
        env['DISPLAY'] = ':0'

        window_id = subprocess.check_output(["xdotool", "getactivewindow"], env=env).strip().decode()
        window_title_raw = subprocess.check_output(["xprop", "-id", window_id, "WM_NAME"], env=env).strip().decode()
        window_title = window_title_raw.split(' = ')[1].strip('"')
        return window_id, window_title
    except (subprocess.CalledProcessError, IndexError) as e:
        print(f"Hindsight Daemon: get_active_window_info failed. Error handled: {e}")
        return None, None

def extract_text_with_tesseract(screenshot_path, text_output_path):
    try:
        ocr_text = subprocess.check_output(
            ["tesseract", screenshot_path, "stdout"], stderr=subprocess.DEVNULL
        ).decode()
        with open(text_output_path, "w", encoding='utf-8') as f:
            f.write(ocr_text)
    except subprocess.CalledProcessError as e:
        print(f"Hindsight Daemon: Tesseract OCR failed with exit code: {e.returncode}")
        pass
    except Exception as e:
        print(f"Hindsight Daemon: Tesseract OCR failed unexpectedly: {e}")

def process_active_window():
    if not processing_lock.acquire(blocking=False):
        return
    try:
        window_id, window_title = get_active_window_info()
        if not window_id or not window_title:
            return
        if any(excluded in window_title.lower() for excluded in EXCLUDED_APPS):
            return

        timestamp = int(time.time())
        new_screenshot_path = os.path.join(SCREENSHOT_DIR, f"{window_id}_{timestamp}.png")
        
        # Explicitly pass the DISPLAY variable to maim
        env = os.environ.copy()
        env['DISPLAY'] = ':0'
        subprocess.run(["maim", "--window", window_id, new_screenshot_path], check=True, capture_output=True, env=env)

        last_screenshot_path = last_screenshot_paths.get(window_id)
        if last_screenshot_path and os.path.exists(last_screenshot_path):
            try:
                img_new = Image.open(new_screenshot_path)
                img_old = Image.open(last_screenshot_path)
                if list(img_new.getdata()) == list(img_old.getdata()):
                    os.remove(new_screenshot_path)
                    return
            except Exception as e:
                print(f"Hindsight Daemon: Image comparison failed: {e}")

        last_screenshot_paths[window_id] = new_screenshot_path
        ocr_filename = os.path.join(OCR_TEXT_DIR, f"{window_id}_{timestamp}.txt")
        extract_text_with_tesseract(new_screenshot_path, ocr_filename)
        
        print(f"Screenshot captured and processed for window: {window_title}")

    except Exception as e:
        print(f"Hindsight Daemon: An unexpected error occurred within a processing cycle: {e}")
    finally:
        processing_lock.release()

def main():
    os.makedirs(SCREENSHOT_DIR, exist_ok=True)
    os.makedirs(OCR_TEXT_DIR, exist_ok=True)
    print("Hindsight Daemon is running...")
    try:
        while True:
            process_active_window()
            time.sleep(POLL_INTERVAL)
    except Exception as e:
        print(f"Hindsight Daemon: A fatal error occurred: {e}")

if __name__ == "__main__":
    main()
