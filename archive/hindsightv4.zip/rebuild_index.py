# /home/gcwyrick/hindsight/app/rebuild_index.py (FAISS Incremental Version)
import os
import glob
import json
import numpy as np
import faiss
import google.generativeai as genai
import time

# --- Gemini API Configuration ---
genai.configure() 

# --- Hindsight Application Configuration ---
BASE_PATH = "/home/gcwyrick/hindsight"
OCR_TEXT_DIR = os.path.join(BASE_PATH, "data", "ocr_text")
INDEX_DIR = os.path.join(BASE_PATH, "data", "faiss_index") # New directory for FAISS
FAISS_INDEX_PATH = os.path.join(INDEX_DIR, "hindsight.faiss")
ID_MAP_PATH = os.path.join(INDEX_DIR, "faiss_id_map.json")

EMBEDDING_SIZE = 768
EMBEDDING_MODEL = "models/text-embedding-004"

def incremental_rebuild_faiss():
    """Performs a fast, incremental update of the FAISS index."""
    print("Starting FAISS index update...")
    os.makedirs(INDEX_DIR, exist_ok=True)

    if os.path.exists(FAISS_INDEX_PATH):
        index = faiss.read_index(FAISS_INDEX_PATH)
        with open(ID_MAP_PATH, 'r', encoding='utf-8') as f:
            id_to_filepath_map = json.load(f)
        print(f"Loaded existing FAISS index with {index.ntotal} items.")
    else:
        index = faiss.IndexFlatIP(EMBEDDING_SIZE)
        id_to_filepath_map = []
        print("No existing index found. Creating a new one.")

    all_files = glob.glob(os.path.join(OCR_TEXT_DIR, "*.txt"))
    processed_files = set(id_to_filepath_map)
    new_files_to_process = [f for f in all_files if f not in processed_files]

    if not new_files_to_process:
        print("No new files to index. Index is up to date.")
        return

    print(f"Found {len(new_files_to_process)} new file(s) to index.")

    new_embeddings = []
    new_filepaths = []
    for i, file_path in enumerate(new_files_to_process):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
                if not text.strip(): continue

            embedding = genai.embed_content(
                model=EMBEDDING_MODEL,
                content=text,
                task_type="retrieval_document"
            )['embedding']

            new_embeddings.append(embedding)
            new_filepaths.append(file_path)
            print(f"Processed {i+1}/{len(new_files_to_process)}: {os.path.basename(file_path)}")

        except Exception as e:
            print(f"Failed to process {file_path}: {e}")
        time.sleep(1)

    if new_embeddings:
        embeddings_array = np.array(new_embeddings).astype('float32')
        index.add(embeddings_array)
        id_to_filepath_map.extend(new_filepaths)

        faiss.write_index(index, FAISS_INDEX_PATH)
        with open(ID_MAP_PATH, 'w', encoding='utf-8') as f:
            json.dump(id_to_filepath_map, f)
        print(f"FAISS index updated and saved. Total items: {index.ntotal}")

if __name__ == "__main__":
    incremental_rebuild_faiss()
