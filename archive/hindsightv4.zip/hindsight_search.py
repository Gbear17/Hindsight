# /home/gcwyrick/hindsight/app/hindsight_search.py (FAISS Version)
import subprocess
import os
import json
import numpy as np
import faiss
import google.generativeai as genai

# --- Gemini API Configuration ---
genai.configure() 

# --- Hindsight Application Configuration ---
BASE_PATH = "/home/gcwyrick/hindsight"
INDEX_DIR = os.path.join(BASE_PATH, "data", "faiss_index") # Updated directory
FAISS_INDEX_PATH = os.path.join(INDEX_DIR, "hindsight.faiss")
ID_MAP_PATH = os.path.join(INDEX_DIR, "faiss_id_map.json")

EMBEDDING_SIZE = 768
EMBEDDING_MODEL = "models/text-embedding-004"

# --- Global State for Memoization ---
faiss_index = None
id_to_filepath_map = []

def init_search_components():
    """Initializes the FAISS index and the file path mapping."""
    global faiss_index, id_to_filepath_map
    if faiss_index is None and os.path.exists(FAISS_INDEX_PATH):
        try:
            faiss_index = faiss.read_index(FAISS_INDEX_PATH)
            with open(ID_MAP_PATH, 'r', encoding='utf-8') as f:
                id_to_filepath_map = json.load(f)
            print(f"FAISS index and file map loaded successfully ({faiss_index.ntotal} items).")
        except Exception as e:
            print(f"Hindsight Search: Failed to load FAISS index or file map: {e}")

def get_recoll_matches(query):
    """Queries Recoll for exact keyword matches."""
    try:
        recoll_command = ["recoll", "-d", "-t", "-q", query]
        search_results_raw = subprocess.check_output(recoll_command).decode().strip()
        return [{"source": "recoll", "content": res} for res in (search_results_raw.split('\n') if search_results_raw else [])]
    except subprocess.CalledProcessError:
        return []

def get_faiss_matches(query, num_results=5):
    """Queries FAISS for semantic matches using the Gemini API."""
    if faiss_index is None or not id_to_filepath_map: return []

    try:
        query_embedding = genai.embed_content(
            model=EMBEDDING_MODEL,
            content=query,
            task_type="retrieval_query"
        )['embedding']

        query_vector = np.array([query_embedding]).astype('float32')
        distances, indices = faiss_index.search(query_vector, num_results)

        results = []
        for i in range(len(indices[0])):
            idx = indices[0][i]
            if idx == -1: continue

            file_path = id_to_filepath_map[idx]
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            results.append({"source": "faiss (gemini)", "content": content, "distance": float(distances[0][i])})
        return results
    except Exception as e:
        print(f"Hindsight Search: FAISS/Gemini search failed: {e}")
        return []

def refine_query_with_gemini(query):
    """Refines the user's query using the Gemini API."""
    try:
        model = genai.GenerativeModel('gemini-1.5-flash-latest')
        prompt = f"Analyze the following user search query to understand the user's intent. Refine the query by adding relevant synonyms, related concepts, or context-aware keywords that would improve a search across text documents. Do not hallucinate information. Respond with only the refined search query string.\nOriginal Query: \"{query}\"\nRefined Query:"
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return query

def hybrid_search(query):
    """Combines Recoll and FAISS results after refining the query with Gemini."""
    init_search_components()
    refined_query = refine_query_with_gemini(query)
    recoll_results = get_recoll_matches(refined_query)
    faiss_results = get_faiss_matches(query)
    return recoll_results + faiss_results

if __name__ == "__main__":
    if len(sys.argv) > 1:
        search_query = " ".join(sys.argv[1:])
        results = hybrid_search(search_query)
        print(json.dumps(results, indent=2))
