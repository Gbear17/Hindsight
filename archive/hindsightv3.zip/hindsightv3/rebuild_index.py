import os
import glob
from sentence_transformers import SentenceTransformer
from annoy import AnnoyIndex

# --- Configuration ---
BASE_PATH = "/home/gcwyrick/hindsight"
OCR_TEXT_DIR = os.path.join(BASE_PATH, "data", "ocr_text")
ANNOY_INDEX_DIR = os.path.join(BASE_PATH, "data", "annoy_index")
ANNOY_INDEX_PATH = os.path.join(ANNOY_INDEX_DIR, "hindsight.ann")
EMBEDDING_SIZE = 384

def rebuild_annoy_index():
    print("Starting Annoy index rebuild...")
    model = SentenceTransformer('all-MiniLM-L6-v2')
    index = AnnoyIndex(EMBEDDING_SIZE, 'angular')
    
    os.makedirs(ANNOY_INDEX_DIR, exist_ok=True)
    
    text_files = glob.glob(os.path.join(OCR_TEXT_DIR, "*.txt"))
    for i, file_path in enumerate(text_files):
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
            if text.strip():
                embedding = model.encode(text)
                index.add_item(i, embedding)
                
    if len(text_files) > 0:
        index.build(10) # 10 trees
        index.save(ANNOY_INDEX_PATH)
        print(f"Annoy index rebuilt successfully with {len(text_files)} items.")
    else:
        print("No text files to index. Skipping rebuild.")

if __name__ == "__main__":
    rebuild_annoy_index()
