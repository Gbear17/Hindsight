import subprocess
import os
import glob
from annoy import AnnoyIndex
from sentence_transformers import SentenceTransformer
import json
import google.generativeai as genai

# --- Gemini API Configuration ---
# Your API key will be used to authenticate with the Gemini API.
# The `genai.configure()` call is set up to use Application Default Credentials
# or you can paste your key directly here if that is a better fit for your setup.
genai.configure() 

# --- Hindsight Application Configuration ---
BASE_PATH = "/home/gcwyrick/hindsight"
OCR_TEXT_DIR = os.path.join(BASE_PATH, "data", "ocr_text")
ANNOY_INDEX_DIR = os.path.join(BASE_PATH, "data", "annoy_index")
ANNOY_INDEX_PATH = os.path.join(ANNOY_INDEX_DIR, "hindsight.ann")
EMBEDDING_SIZE = 768

# --- Global State for Memoization ---
model = None
annoy_index = None
text_file_paths = []

def init_search_components():
    """Initializes the Sentence Transformer model and Annoy index."""
    global model, annoy_index, text_file_paths
    if model is None:
        model = SentenceTransformer('all-MiniLM-L6-v2')
    if annoy_index is None:
        try:
            annoy_index = AnnoyIndex(EMBEDDING_SIZE, 'angular')
            annoy_index.load(ANNOY_INDEX_PATH)
            text_file_paths = glob.glob(os.path.join(OCR_TEXT_DIR, "*.txt"))
        except Exception as e:
            annoy_index = None

def get_recoll_matches(query):
    """Queries Recoll for exact keyword matches."""
    try:
        recoll_command = ["recoll", "-d", "-t", "-q", query]
        search_results_raw = subprocess.check_output(recoll_command).decode().strip()
        search_results = search_results_raw.split('\n') if search_results_raw else []
        return [{"source": "recoll", "content": res} for res in search_results]
    except subprocess.CalledProcessError:
        return []

def get_annoy_matches(query, num_results=5):
    """Queries Annoy for semantic matches."""
    if annoy_index is None:
        return []
    
    query_embedding = model.encode(query)
    annoy_results = annoy_index.get_nns_by_vector(query_embedding, num_results, include_distances=True)
    
    results = []
    for item_id, distance in zip(annoy_results[0], annoy_results[1]):
        file_path = text_file_paths[item_id]
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        results.append({"source": "annoy", "content": content, "distance": distance})
    
    return results

def refine_query_with_gemini(query):
    """Refines the user's query using the Gemini API."""
    try:
        model = genai.GenerativeModel('gemini-2.5-flash-latest')
        prompt = f"""
        Analyze the following user search query to understand the user's intent. Refine the query by adding relevant synonyms, related concepts, or context-aware keywords that would improve a search across text documents. Do not hallucinate information. Respond with only the refined search query string.
        Original Query: "{query}"
        Refined Query:
        """
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print(f"Hindsight Search: Gemini API failed: {e}")
        return query # Fallback to the original query on error

def hybrid_search(query):
    """Combines Recoll and Annoy results."""
    init_search_components()
    
    # Use Gemini to refine the query
    refined_query = refine_query_with_gemini(query)
    
    recoll_results = get_recoll_matches(refined_query)
    annoy_results = get_annoy_matches(refined_query)
    
    combined_results = recoll_results + annoy_results
    return combined_results

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        search_query = " ".join(sys.argv[1:])
        results = hybrid_search(search_query)
        print(json.dumps(results))
