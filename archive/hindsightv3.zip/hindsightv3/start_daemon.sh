#!/bin/bash
cd /home/gcwyrick/hindsight/app/
source venv/bin/activate
python memory_daemon.py
