import os
import json
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from hindsight_search import hybrid_search

app = Flask(__name__)
CORS(app) # This is the new line to enable CORS

# Route to serve the OpenAPI specification file
@app.route('/openapi.json', methods=['GET'])
def get_openapi_json():
    return send_from_directory(os.path.dirname(os.path.abspath(__file__)), 'openapi.json')

# Route to handle search queries from Open WebUI
@app.route('/search', methods=['POST'])
def search_endpoint():
    try:
        data = request.get_json()
        query = data.get('query')
        if not query:
            return jsonify({'error': 'No query provided'}), 400

        results = hybrid_search(query)
        return jsonify(results)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
